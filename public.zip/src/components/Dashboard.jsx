import React from 'react';

const Dashboard = ({ username }) => {
  return (
    <div>
      <h2>Welcome, {username}!</h2>
      {/* Add dashboard content here */}
    </div>
  );
};

export default Dashboard;