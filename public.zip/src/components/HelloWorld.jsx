import React from "react";
function HelloWorld()
{
    return (
        <p>Hello, World</p>
    )

}
export const ava =()=>{
    return(
        <>
        icici</>
    )
}
export const noo =()=>{
    return(
        <>
        noo</>
    )
}
export default HelloWorld;